package org.pitest.classinfo;

public interface HashFunction {

  long hash(byte[] value);

}
