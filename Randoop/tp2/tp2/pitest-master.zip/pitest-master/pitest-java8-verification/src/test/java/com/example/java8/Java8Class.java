package com.example.java8;

/**
 * @author iirekm@gmail.com
 */
public class Java8Class {
    public int foo() {
        int i = 1;
        i++;
        i++;
        return i;
    }
}
