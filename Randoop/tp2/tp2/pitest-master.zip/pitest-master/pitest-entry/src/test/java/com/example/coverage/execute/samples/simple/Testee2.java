package com.example.coverage.execute.samples.simple;

public class Testee2 {
  public void foo() {

  }

  public void bar() {

  }
}
