package com.example.coverage.execute.samples.exceptions;

public class CoveredBeforeExceptionTestee {
  static int i;

  public static void bar() {
    i++;
  }
}
