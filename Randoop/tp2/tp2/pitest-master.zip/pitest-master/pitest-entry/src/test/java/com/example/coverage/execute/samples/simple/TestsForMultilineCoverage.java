package com.example.coverage.execute.samples.simple;

import org.junit.Test;

import com.example.MultiLineCoverageTestee;

public class TestsForMultilineCoverage {

  private final MultiLineCoverageTestee t = new MultiLineCoverageTestee();

  @Test
  public void test1() {
    this.t.lines1(1);
  }

  @Test
  public void test2() {
    this.t.lines2(1);
  }

  @Test
  public void test3() {
    this.t.lines3(1);
  }

  @Test
  public void test4() {
    this.t.lines4(1);
  }

  @Test
  public void test5() {
    this.t.lines5(1);
  }

  @Test
  public void test6() {
    this.t.lines6(1);
  }

  @Test
  public void test7() {
    this.t.lines7(1);
  }

  @Test
  public void test8() {
    this.t.lines8(1);
  }

  @Test
  public void test9() {
    this.t.lines9(1);
  }

  @Test
  public void test10() {
    this.t.lines10(1);
  }

  @Test
  public void test11() {
    this.t.lines11(1);
  }

  @Test
  public void test12() {
    this.t.lines12(1);
  }

  @Test
  public void test13() {
    this.t.lines13(1);
  }

  @Test
  public void test14() {
    this.t.lines14(1);
  }

  @Test
  public void test15() {
    this.t.lines15(1);
  }

  @Test
  public void test30() {
    this.t.lines30(1);
  }
}