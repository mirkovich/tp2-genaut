package com.example.coverage.execute.samples.simple;

import org.junit.Test;

import com.example.MultiBlockCoverageTestee;

public class TestsForMultiBlockCoverage {

  @Test
  public void test1() {
    MultiBlockCoverageTestee.blocks1(1);
  }

  // @Test
  // public void test2() {
  // try {
  // MultiBlockCoverageTestee.blocks2(1);
  // } catch(UnsupportedOperationException e) {
  //
  // }
  // }

  @Test
  public void test3() {
    MultiBlockCoverageTestee.blocks3(1);
  }

  @Test
  public void test4() {
    MultiBlockCoverageTestee.blocks4(1);
  }

  @Test
  public void test5() {
    MultiBlockCoverageTestee.blocks5(1);
  }

  @Test
  public void test6() {
    MultiBlockCoverageTestee.blocks6(1);
  }

  @Test
  public void test7() {
    MultiBlockCoverageTestee.blocks7(1);
  }

  @Test
  public void test8() {
    MultiBlockCoverageTestee.blocks8(1);
  }

  @Test
  public void test9() {
    MultiBlockCoverageTestee.blocks9(1);
  }

  @Test
  public void test10() {
    MultiBlockCoverageTestee.blocks10(1);
  }

  @Test
  public void test11() {
    MultiBlockCoverageTestee.blocks11(1);
  }

  @Test
  public void test12() {
    MultiBlockCoverageTestee.blocks12(1);
  }

  @Test
  public void test13() {
    MultiBlockCoverageTestee.blocks13(1);
  }

  @Test
  public void test14() {
    MultiBlockCoverageTestee.blocks14(1);
  }

  @Test
  public void test15() {
    MultiBlockCoverageTestee.blocks15(1);
  }

  @Test
  public void testMany() {
    MultiBlockCoverageTestee.blocksMany(1);
  }
}