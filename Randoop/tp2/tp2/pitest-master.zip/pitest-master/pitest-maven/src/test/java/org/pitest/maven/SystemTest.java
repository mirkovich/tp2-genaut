package org.pitest.maven;

public interface SystemTest {

}
