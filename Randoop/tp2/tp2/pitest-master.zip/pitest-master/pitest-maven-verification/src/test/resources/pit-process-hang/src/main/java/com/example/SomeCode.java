package com.example;

public class SomeCode {

   public void generateLotsOfOutput() {
     for ( int i = 0; i != 10000; i++) {
       System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA " + i);
     }
   }

}
