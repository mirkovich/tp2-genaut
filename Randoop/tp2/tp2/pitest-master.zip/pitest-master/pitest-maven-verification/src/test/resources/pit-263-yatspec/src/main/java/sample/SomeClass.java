package sample;

public class SomeClass {

    public int theAnswer(String question) {
        if ("life the universe and everything".equals(question)) {
            return 42;
        } else {
            return -1;
        }
    }
}
